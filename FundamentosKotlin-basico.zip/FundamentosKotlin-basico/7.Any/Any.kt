//uso del tipo de dato any
fun main() {
  
    var cualquiera:Any = 18.18f
    
    println(cualquiera)
}