/*Ciclos while do-while */
fun main() {
    var x = 0
    //uso del bucle while   
    while (x<=10){ 
       if(x == 8) println(x)
       x = x + 2
    }

    //uso del bucle do while
    var y = 1   
    do{  
      print("Estoy adentro del do while")      
    }while(y!=1)     
}