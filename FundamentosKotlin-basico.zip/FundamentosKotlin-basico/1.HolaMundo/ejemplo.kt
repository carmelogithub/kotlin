class ejemplo {

    fun main() {
        val hola:String = "Yesser"
        var apellido:String = "Miranda"
        println("Bienvenido a mi primer programa ${hola} $apellido")
    }
}