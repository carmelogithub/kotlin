package com.hello.kotlin

fun main() {
    val hola:String = "Juan"
    var apellido:String = "López"
    println("Bienvenido a mi primer programa ${hola} $apellido")
}