fun main(args: Array<String>) {
 
    var caracter:Char = 'a'
    val valorA:Int = caracter.toInt()
 
    println(caracter + " es " + valorA + " en ASCII")
 
    var cadena:String = "En un lugar de la mancha"
    
    println(cadena)
  
}