class Frutas(color:String,sabor:String,precio:Int){    
    var color:String = ""
    var sabor:String = ""
    var precio:Int = 0
    
    init{
       this.color = color
       this.sabor = sabor
       this.precio = precio
    }
    
    fun comer(){  
      print("Como fruta")      
    }    
}

fun main() {
   var manzana = Frutas("Rojo","Dulce",4)
   println(manzana.color) 
   manzana.comer()      
}