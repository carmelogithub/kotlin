# Fundamentos de Kotlin
![Imagen de android](https://developer.android.com/images/kotlin/android-plus-kotlin.png)
Bienvenido a un repositorio con los códigos básicos del lenguaje de programación Kotlin, es recomendable que sean compilados de forma externa al IDE de android.

### Razones para elegir Kotlin
Desde Google I/O 2019, el desarrollo móvil paso a ser kotlin de primero.
* Menos código combinado con mayor legibilidad
* Lenguaje y entorno maduros
* Interoperabilidad con Java
* Soporte para desarrollo multiplataforma
* Seguridad de código
* Fácil aprendizaje
