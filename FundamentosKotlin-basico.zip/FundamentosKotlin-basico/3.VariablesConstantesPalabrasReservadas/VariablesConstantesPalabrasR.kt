/*
Programa de variables y contantes */
 
fun main(args: Array<String>) {
    
    //usando variables
    var edad = 18
    edad = 15
    var nombre = "Juan López"
    nombre = "Juan"
    println(nombre)

    //usando constantes
    val pi = 3.14
    //pi=4 //no se puede por ser inmutable
    println(pi*2)

}